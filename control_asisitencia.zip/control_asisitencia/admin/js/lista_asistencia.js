/* jQuery(document).ready(function($){
    $("#btnMarcar").click(function(){
        console.log('Si funciona'); 
        $(this).grabarAsistencia(); 
        $.ajax({
            type: "post",
            
        }) 
        $("#modalinsert").modal("show");
    });
});
 */

document.getElementById('#btnMarcarA',addEventListener('click',function(){
    this.alert('Ejecutado');
}));